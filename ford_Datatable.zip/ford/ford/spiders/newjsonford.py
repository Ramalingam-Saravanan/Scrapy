import scrapy
import re
import json
from w3lib.html import remove_tags


class jsonford(scrapy.Spider):
    name='job1'
    start_urls=[
        'https://sjobs.brassring.com/TGWebHost/home.aspx?partnerid=25385&siteid=5283'
        ]
    numJobsSeen = 0
    def parse(self, response):
         jobs_india_Homepage=response.xpath("//span[@id='ctl00_MainContent_spnNonLoginLandingPageCustomText']//a/@href").extract_first()
         yield response.follow(jobs_india_Homepage, self.parse_homepage)
         
    def parse_homepage(self, response):
         jobs = []
         a=response.xpath("//table[@title='Search results']//input[@id='ctl00_MainContent_GridFormatter_json_tabledata']/@value").extract_first()
         print("Hai homepage")
         #print(a)
         k=json.loads(a)
         #j=k["value"]
         for x in k:
                # debug
                print ('\n'.join('%s\t%s' % (y,z) for y,z in x.items()))
                print ('\n')
                
                #Creating a Dictionary to store values
                job = {}
                
                job['Company_Name'] = self.get_companyname_from_job_dict(x)
                job['Job_Title'] = self.get_JobTitle_from_job_dict(x)
                job['Skills'] = self.get_title_from_job_dict(x)
                job['location'] = self.get_location_from_job_dict(x)
                job['Positions_Remaining'] = self.get_PositionsRemaining_from_job_dict(x)
                job['LastUpdated'] = self.get_LastUpdated_from_job_dict(x)
                
                #job['url'] = self.get_url_from_job_dict(x)

                #jobs.append(job)
                yield job
                
         #print(jobs)
         #yield jobs
         #b=response.xpath("//span[@id='yui-pg0-1-next-span']/text()").extract_first()
         #print(b)
                
    def get_title_from_job_dict(self, job_dict):
        t = job_dict['FORMTEXT19']
        return t
        
    def get_PositionsRemaining_from_job_dict(self, job_dict):
        t = job_dict['PositionsRemaining']    
       
        return t
    def get_location_from_job_dict(self, job_dict):
        l = job_dict['FORMTEXT12'] + ', ' + job_dict['FORMTEXT7']
        l = l.strip()
        return l
    def get_companyname_from_job_dict(self, job_dict):
        t = job_dict['FORMTEXT8']
        return t
                
    def get_JobTitle_from_job_dict(self, job_dict):
        t = job_dict['JobTitle']
        return t
    def get_LastUpdated_from_job_dict(self, job_dict):
        t = job_dict['LastUpdated']
        t= remove_tags(t).strip()
        
        return t
        
    #try    
    def seen_all_jobs(self):
        
        self.br.select_form('frmMassSelect')
        return self.numJobsSeen >= int(self.br.form['totalrecords'])

    def goto_next_page(self):
        self.br.select_form('frmMassSelect')
        self.br.form.set_all_readonly(False)
        self.br.form['recordstart'] = '%d' % (self.numJobsSeen + 1)
        self.br.submit()
        self.soup = BeautifulSoup(self.br.response().read())
        
         
         